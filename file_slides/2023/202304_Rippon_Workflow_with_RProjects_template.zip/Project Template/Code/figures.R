
# ___________________________________ #
#        Example Plotting File        #
# ___________________________________ #
#
# Created:      13 April 2023
# Last Updated: 14 April 2023
#
# ~ creates plots from [iris]
#
# Brady Rippon
# ___________________________________ #


# load in packages
library(tidyverse)
library(tidylog)
library(here)
library(expss)
library(ggpubr)

# load data
load(file = here("Data/Derived", "iris_14APR2023.Rdata")) 

# create plots

sepal_plot <- iris %>% ggplot(aes(x = Sepal.Width, y = Sepal.Length, 
                    fill = Species, size = Sepal.Area)) +
  scale_fill_manual(values=c("#999999", "#E69F00", "#56B4E9")) +
  geom_point(shape = 21, color = "black") +
  xlab("Sepal Width (cm)") + ylab("Sepal Length (cm)") +
  guides(size = guide_legend(title = "Sepal Area")) +
  theme_bw() +
  theme(legend.position = "bottom",
        legend.direction = "vertical")


petal_plot <- iris %>% ggplot(aes(x = Petal.Width, y = Petal.Length, 
                    fill = Species, size = Petal.Area)) +
  scale_fill_manual(values=c("#999999", "#E69F00", "#56B4E9")) +
  geom_point(shape = 21, color = "black") +
  xlab("Petal Width (cm)") + ylab("Petal Length (cm)") +
  guides(size = guide_legend(title = "Petal Area")) +
  theme_bw() +
  theme(legend.position = "bottom",
        legend.direction = "vertical")

# combine plots
iris_plot <- ggarrange(sepal_plot, petal_plot, nrow = 1, align = "h")

# save figure
ggsave(
  "irisSizes14APR2023.tiff",
  plot = iris_plot,
  path = here("Figures"),
  width = 7, height = 5, units = "in",
  dpi = 300
)



