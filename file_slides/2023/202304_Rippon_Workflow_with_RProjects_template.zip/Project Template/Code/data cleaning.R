
# ___________________________________ #
#      Example Data Cleaning File     #
# ___________________________________ #
#
# Created:      13 April 2023
# Last Updated: 14 April 2023
#
# ~ cleans the data for presentation
#
# Brady Rippon
# ___________________________________ #


# load in packages
library(tidyverse)
library(tidylog)
library(here)
library(readxl)

# import dataset
iris_raw <- read_csv(here("Data/Raw", "iris.csv")) 

# clean + edit dataset
iris <- iris_raw %>% 
  mutate(Sepal.Area = Sepal.Length*Sepal.Width,
         # find when sepal is 1+SD greater than mean size (area)
         Sepal.Big = case_when(
           Sepal.Area > mean(Sepal.Area) + sd(Sepal.Area) ~ 1,
           T ~ 0
           ),
         Petal.Area = Petal.Length*Petal.Width,
         # find when petal is 1+SD greater than mean size (area)
         Petal.Big = case_when(
           Petal.Area > mean(Petal.Area) + sd(Petal.Area) ~ 1,
           T ~ 0
         ),
         # when are petal and sepal both big
         Total.Big = case_when(
           Sepal.Big + Petal.Big == 2 ~ 1,
           T ~ 0
         ),
         Species = str_to_title(Species)) %>% # [!] # end of mutate
  select(Species,
         Sepal.Big, Sepal.Area, Sepal.Length, Sepal.Width,
         Petal.Big, Petal.Area, Petal.Length, Petal.Width,
         Total.Big)


# save edited dataset
save(iris, file = here("Data/Derived", "iris_14APR2023.Rdata"))


# rm(list=ls())

