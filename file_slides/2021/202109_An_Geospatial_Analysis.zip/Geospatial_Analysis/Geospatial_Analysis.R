
##################################################
#                                                #
#          Geospatial Analysis in R              #
#                                                #
##################################################

# install packages
install.packages(c("maps", "sf", "tmap", "mapproj"))

# load packages
library(tidyverse)
library(ggplot2)
library(maps)
library(sf)
library(tmap)
library(mapproj)

##################################################
#                                                #
#           Mapping with ggplot                  #
#                                                #
##################################################


# Loading data: 

# load milk production data

# load us_states from maps



# Joining the US States map with 2017 milk production:



# Plotting milk production:



# Adding geometries: 

# example cities
ne_cities <- tibble::tribble( 
  ~city,           ~lat,     ~long,
  "NYC",    40.730610, -73.935242,
  "Boston", 42.361145, -71.057083
)




##################################################
#                                                #
#       Mapping with sf and tmap                 #
#                                                #
##################################################

# Load shapes with sf ([s]hape[f]iles):

# read in shapefile


# print out sf object


# View


# check class of sf object


# look at the geometry


# just plot out Boroname


# you can drop geometry and just get table


# filtering with dplyr works!


# methods with sf





# Quickly plotting shapes: - tm = thematic maps



# Plot them together: 



# Adding features (compass, legend, credits etc): 







